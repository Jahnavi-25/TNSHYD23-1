package com.example.demo.Service;

import java.util.List;

import com.example.demo.Entity.Shop;

public interface ShopService {
	   
		Shop saveShop(Shop shop);
		
		List<Shop> fetchShopList();
		
		Shop fetchShopById(Long id);
		
		void deleteShopById(Long id);
		
}
