package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.example.demo.Entity.Shop;
import com.example.demo.Service.ShopService;



@RestController
public class ShopController {
    @Autowired
    ShopService service;
    @PostMapping("/shop")
    public Shop saveShop(@RequestBody Shop shop) {
           
   	 	return service.saveShop(shop);
       }
    
    @GetMapping("/shop")
    public List<Shop> fetchShopList() {
   	 
        return service.fetchShopList();
    }
    
    @GetMapping("/shop/{id}")
    public Shop fetchShopById(@PathVariable("id") Long id) 
    {
        return service.fetchShopById(id);
    }
    
    @DeleteMapping("/shop/{id}")
    public String deleteShopById(@PathVariable("id") Long id) 
    {
    	service.deleteShopById(id);
    	return "Shop deleted Successfully!!";
    }
    
 
    
    
}
