package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Shop;
import com.example.demo.Repository.ShopRepository;



@Service
public class ShopServiceImpl implements ShopService {
	
	@Autowired
	
	ShopRepository shopRepository;

	@Override
	public Shop saveShop(Shop shop) {
		// TODO Auto-generated method stub
		return shopRepository.save(shop);
	}

	@Override
	public List<Shop> fetchShopList() {
		// TODO Auto-generated method stub
		return shopRepository.findAll();
	}

	@Override
	public Shop fetchShopById(Long id) {
		// TODO Auto-generated method stub
		return shopRepository.findById(id).get();
	}

	@Override
	public void deleteShopById(Long id) {
		// TODO Auto-generated method stub
		shopRepository.deleteById(id);
	}
	
	
	  
	

}
