/**
 * 
 */
/**
 * 
 */
module prog1 {
}