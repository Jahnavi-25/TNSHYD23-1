package com.oop;

public class Main2getterssetters {

	public static void main(String[] args) {
		Emp2getterssetters e2= new Emp2getterssetters();
		e2.setSalary(50000);
		System.out.println(e2.getSalary());
		e2.setName("xyz");
		System.out.println(e2.getName());
}
}
