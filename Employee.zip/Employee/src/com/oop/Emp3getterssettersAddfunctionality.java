package com.oop;

public class Emp3getterssettersAddfunctionality {
	private String name;
	private int id;
	private int age;
	public int salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String experience() {
		if(name.equals("xyz") && id >0 && age >22 
				&& salary >40000)  
		{
			return "employee is experienced";
		}else {
			return "employee is not experienced";
		}
	}
}
