package com.oop;

public class Main1 {

	public static void main(String[] args) {
		Emp1 e1= new Emp1();
		e1.salary=35000;
		System.out.println(e1.salary);
}
}
