package com.oop;

public class Emp1 {
private String name;
private int id;
private int age;
public int salary;
}
