package com.oop;

public class Main3getterssettersAddfunctionality {

	public static void main(String[] args) {
	Emp3getterssettersAddfunctionality emp = new Emp3getterssettersAddfunctionality();
		emp.setAge (30);
		emp.setName ("xyz");
		emp.setSalary (70000);
		emp.setId (10);
		//calling the function
		System.out.println (emp.experience ());
	}
}
