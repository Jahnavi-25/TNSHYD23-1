package App2;

public class Employee {
	int id=5;
	static int num=25;
	int display() {
		return 10;
	}
	static void display1() {
		System.out.println(10);
	}
	}
class company{
	public static void main(String[] args) {
	Employee e1 = new Employee();
	System.out.println(e1.id);
	e1.display();
	System.out.println(Employee.num);
	Employee.display1();

	}

}
