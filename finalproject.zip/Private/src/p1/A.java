package p1;
class A {
private void display()
{
System.out.println("TNS Sessions");
}
}
