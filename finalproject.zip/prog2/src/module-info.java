/**
 * 
 */
/**
 * 
 */
module prog2 {
}