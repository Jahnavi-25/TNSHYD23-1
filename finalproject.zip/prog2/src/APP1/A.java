package APP1;

public class A {
	int p=5;
	static int q=10;
	int display() {
		return 20;
	}
	static void display1() {
		System.out.println(20);
	}
	public static void main(String[] args) {
		int a=10;
		System.out.println(a);
		A a1 =new A();
		System.out.println(a1.p);
		a1.display();
		System.out.println(A.q);
		A.display1();
	}
	}
	
