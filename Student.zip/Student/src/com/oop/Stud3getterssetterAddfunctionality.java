package com.oop;

public class Stud3getterssetterAddfunctionality {
	private String name;
	private int id;
	private String branch;
	public int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String eligible() {
		if(name.equals("abc") && id >0 && branch.equals("ds") 
				&& age >18)  
		{
			return "student is eligible";
		}else {
			return "student is not eligible";
		}
	}
}

