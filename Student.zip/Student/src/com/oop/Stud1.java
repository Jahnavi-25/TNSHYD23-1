package com.oop;

public class Stud1 
{
	private String name;
	private int id;
	private String branch;
	public int age;
}
