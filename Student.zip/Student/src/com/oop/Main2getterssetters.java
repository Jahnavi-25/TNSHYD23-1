package com.oop;

public class Main2getterssetters {

	public static void main(String[] args) {
		Stud2getterssetters s2= new Stud2getterssetters();
		s2.setAge(25);
		System.out.println(s2.getAge());
		
		
		s2.setName("abc");
		System.out.println(s2.getName());
}
}
