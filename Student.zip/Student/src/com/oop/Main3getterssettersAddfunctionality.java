package com.oop;

public class Main3getterssettersAddfunctionality {

	public static void main(String[] args) {
	Stud3getterssetterAddfunctionality stud = new Stud3getterssetterAddfunctionality ();
		stud.setAge (30);
		stud.setName ("abc");
		stud.setBranch ("ds");
		stud.setId (10);
		//calling the function
		System.out.println (stud.eligible ());
	}

}
