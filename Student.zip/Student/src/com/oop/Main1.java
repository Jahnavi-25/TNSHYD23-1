package com.oop;

public class Main1 {

	public static void main(String[] args) {
		Stud1 s1= new Stud1();
		s1.age=25;
		System.out.println(s1.age);
	}
}
